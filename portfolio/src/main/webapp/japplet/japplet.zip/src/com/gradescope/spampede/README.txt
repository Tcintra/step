Spampede README.txt

Please complete the template below, replacing the text between 
the ** symbols with your own text.

Parts of the project completed/not completed:

   ** 
      I completed all parts of the project including the extra credit
   **

Known bugs:  

   ** 
      I did not encounter any bugs!
   **

Extra features that were added:

   ** 
      I added one enemy snake. It gets initialized at the start of the game with size 2, on the bottom right 
      of the board and it is red. I also added a text display with the number of kills a player got. It always moves
      to the west side of the board. When it hits a wall, it randomly gets placed somewhere else on the 
      board and its size gets increased by 1. If the player hits the enemy snake's body, the game is over.
      If the player hits the enemy snake's head, the player gains 1 kill and the enemy snake's size gets reset
      and it is placed back to the bottom-right corner of the board. If the enemy snake hits the player's body,
      it also dies and the same thing happens. The enemy snake moves at 1/3 the speed of the player.
   ** 

(Optional) Comments about this project:

	 *Please tell us any thoughts you had on this project - what
	 you enjoyed or didn't enjoy, what was challenging, or anything else.*

